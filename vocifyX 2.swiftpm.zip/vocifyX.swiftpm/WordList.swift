let predefinedWords = [
    // A
    "apple",        // Easy
    "astronaut",    // Medium
    "anemone",      // Difficult
    
    // B
    "banana",       // Easy
    "balloon",      // Medium
    "basilisk",     // Difficult
    
    // C
    "cat",          // Easy
    "castle",       // Medium
    "chrysanthemum",// Difficult
    
    // D
    "dog",          // Easy
    "dolphin",      // Medium
    "dodecahedron", // Difficult
    
    // E
    "egg",          // Easy
    "elephant",     // Medium
    "epiphany",     // Difficult
    
    // F
    "fish",         // Easy
    "forest",       // Medium
    "fossiliferous",// Difficult
    
    // G
    "goat",         // Easy
    "galaxy",       // Medium
    "gastroenterologist", // Difficult
    
    // H
    "hat",          // Easy
    "horizon",      // Medium
    "hippopotamus", // Difficult
    
    // I
    "ice",          // Easy
    "island",       // Medium
    "ichthyosaurus",// Difficult
    
    // J
    "jam",          // Easy
    "journey",      // Medium
    "juxtaposition",// Difficult
    
    // K
    "kite",         // Easy
    "kitchen",      // Medium
    "kaleidoscope", // Difficult
    
    // L
    "lamp",         // Easy
    "lighthouse",   // Medium
    "lycanthrope",  // Difficult
    
    // M
    "map",          // Easy
    "mountain",     // Medium
    "metamorphosis",// Difficult
    
    // N
    "net",          // Easy
    "nebula",       // Medium
    "neuroscientist", // Difficult
    
    // O
    "owl",          // Easy
    "oasis",        // Medium
    "onomatopoeia", // Difficult
    
    // P
    "pen",          // Easy
    "paradise",     // Medium
    "phosphorescent", // Difficult
    
    // Q
    "quiz",         // Easy
    "quartz",       // Medium
    "quintessential", // Difficult
    
    // R
    "rat",          // Easy
    "rainbow",      // Medium
    "reverberation", // Difficult
    
    // S
    "sun",          // Easy
    "starfish",     // Medium
    "sesquicentennial", // Difficult
    
    // T
    "tap",          // Easy
    "treasure",     // Medium
    "transcendental", // Difficult
    
    // U
    "urn",          // Easy
    "universe",     // Medium
    "uncharacteristically", // Difficult
    
    // V
    "van",          // Easy
    "voyage",       // Medium
    "ventriloquist",// Difficult
    
    // W
    "web",          // Easy
    "waterfall",    // Medium
    "wunderkind",   // Difficult
    
    // X
    "x-ray",        // Easy
    "xenon",        // Medium
    "xylophonist",  // Difficult
    
    // Y
    "yarn",         // Easy
    "yearning",     // Medium
    "yesteryear",   // Difficult
    
    // Z
    "zoo",          // Easy
    "zenith",       // Medium
    "zoetrope"      // Difficult
]
